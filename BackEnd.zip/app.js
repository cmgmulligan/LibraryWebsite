const express = require('express');
const cors = require('cors');
const PORT = 80;
const app = express();
const bodyParser = require('body-parser');
const AWS = require('aws-sdk');


app.use(cors());
app.use(bodyParser.json());

var urlencodedParser = bodyParser.urlencoded({extended: false});

app.listen(PORT);

AWS.config.update({
    region: "eu-west-1",
    endpoint: 'https://dynamodb.eu-west-1.amazonaws.com'
});

var docClient = new AWS.DynamoDB.DocumentClient();

app.post('/',urlencodedParser,(req,res) => {
    var params = {
        TableName : "booklibrary",
        Key:{
            "title": req.body.Title
        }
    };
    docClient.get(params, (err,data) => {
        if(err) res.send(false);
        else res.send(JSON.stringify(data));
    });
});