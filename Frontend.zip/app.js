const express = require('express');
const app = express();
const PORT = 80;

app.get('/', (req,res) => {
    if(req.body != null) console.log(JSON.parse(req.body));
    res.sendFile(__dirname+'/index.html');
});

app.get('/images/generic_book_cover.jpg', (req,res) => {
    res.sendFile(__dirname+'/images/generic_book_cover.jpg');
});

app.get('/css/style.css', (req,res) => {
    res.sendFile(__dirname+'/css/style.css');
});

app.get('/css/bookContainerStyle.css', (req,res) => {
    res.sendFile(__dirname+'/css/bookContainerStyle.css');
});

app.get('/js/index.js', (req,res) => {
    res.sendFile(__dirname+'/js/index.js');
});

app.listen(PORT)