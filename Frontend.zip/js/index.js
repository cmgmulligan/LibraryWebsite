function LoadBook(ele) {
    var bookName = ele.id;
    var request = new XMLHttpRequest();
    request.open('POST', 'http://BackEndLB-849219339.eu-west-1.elb.amazonaws.com');
    request.setRequestHeader("Content-Type", "application/json");
    request.onload = () => {
        if (request.status >= 200 && request.status < 400) {
            var data = JSON.parse(request.response);
            CreateBookCard(data);
        }
        else console.log('error');
        }
    request.send(JSON.stringify({"Title": `${bookName}`}));
}

function Search() {
    search = document.getElementById('searchBar').value;
    search = search.replace(/\s/g, '');
    var request = new XMLHttpRequest();
    request.open('POST', 'http://BackEndLB-849219339.eu-west-1.elb.amazonaws.com');
    request.setRequestHeader("Content-Type", "application/json");
    request.onload = () => {
        if (request.status >= 200 && request.status < 400) {
            var data = JSON.parse(request.response);
            CreateBookCard(data);
        }
        else console.log('error');
        }
    request.send(JSON.stringify({"Title": search.toLowerCase()}));
}

function CreateBookCard(data) {
    let bookContainer = document.getElementById('books-container');
    while(bookContainer.lastElementChild) {
        bookContainer.removeChild(bookContainer.lastElementChild);
    }
    let card = document.createElement('div');
    bookContainer.appendChild(card);
    card.setAttribute('class', 'card');

    let cover = document.createElement('img');
    cover.setAttribute('class', 'cover')
    cover.setAttribute('src', data.Item.info.bookcover);
    card.appendChild(cover);
    
    let infoContainer = document.createElement('div');
    infoContainer.setAttribute('id', 'infoContainer')
    card.appendChild(infoContainer);

    let table = document.createElement('table');
    table.setAttribute('class', 'infoTable')
    infoContainer.appendChild(table);

    for(var i = 0; i < 4; i++){
        let tr = document.createElement('tr');
        for(var j = 0; j < 2; j++) {
            let td = document.createElement('td');
            switch(i) {
                case 0:
                    td.innerHTML= (j==0) ? "Title:" : data.Item.info.booktitle;
                    break;
                case 1:
                    td.innerHTML= (j==0) ? "Author:" : data.Item.info.author;
                    break;
                case 2:
                    td.innerHTML= (j==0) ? "Published:" : data.Item.info.yearpublished;
                    break;
                case 3:
                    td.innerHTML= (j==0) ? "Genre:" : data.Item.info.genre;
                    break;
            }
            tr.appendChild(td);
        }
        table.appendChild(tr);
    }

    let readButton = document.createElement('a');
    readButton.innerHTML="Read";
    readButton.setAttribute('id', 'readButton');
    readButton.setAttribute('href', data.Item.info.bookpdf);
    infoContainer.appendChild(readButton);
}

function HandleKeyPress(e){
    var key = e.key;
    if(key === "Enter") {
        Search();
    }
}